import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Success here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Success extends World
{

    /**
     * Constructor for objects of class Success.
     * 
     */
    public Success()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(400, 400, 1); 
    }
    public void act()
    {
        showText("Press Enter to Continue", 200, 350);
        if (Greenfoot.isKeyDown("ENTER")&&(GameOver.worldNumber == 1))
        {
            Greenfoot.setWorld(new MyWorld_2());
        }
        if (Greenfoot.isKeyDown("ENTER")&&(GameOver.worldNumber == 2))
        {
            Greenfoot.setWorld(new MyWorld_3());
        }
    }
}
