import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class launcher here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class launcher extends Actor
{   
    public static int counter = 0;
    public static int timer = 0;
    /**
     * Act - do whatever the launcher wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(timer % 500 == 0)
        {
            shootBullet();
            counter++;
        }
    }
    public void shootBullet()
    {
            bullet counter = new bullet();
            getWorld().addObject(counter,getX()+13, getY()-7);
    }
}
