import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ball here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ball extends Actor
{   
    private GreenfootImage ball1 = new GreenfootImage("Ball1.png");
    private GreenfootImage ball2 = new GreenfootImage("Ball2.png");
    private GreenfootImage ball3 = new GreenfootImage("Ball3.png");
    private GreenfootImage ball4 = new GreenfootImage("Ball4.png");
    private GreenfootImage ball5 = new GreenfootImage("Ball5.png");
    private GreenfootImage ball6 = new GreenfootImage("Ball6.png");
    private GreenfootImage ball7 = new GreenfootImage("Ball7.png");
    private GreenfootImage ballL1 = new GreenfootImage("BallL1.png");
    private GreenfootImage ballL2 = new GreenfootImage("BallL2.png");
    private GreenfootImage ballL3 = new GreenfootImage("BallL3.png");
    private GreenfootImage ballL4 = new GreenfootImage("BallL4.png");
    private GreenfootImage ballL5 = new GreenfootImage("BallL5.png");
    private GreenfootImage ballL6 = new GreenfootImage("BallL6.png");
    private GreenfootImage ballL7 = new GreenfootImage("BallL7.png");
    
    public static boolean animationRoll = true;
    private int frame = 1;
    private int animationCounter = 0;
    private final int GRAVITY = 1;
    private int velocity;
    public static int speed = -3;
    public static boolean movingLeft = true;
    /**
     * Act - do whatever the ball wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       fall();
       move(speed);
       animationCounter ++;
       rollAround();
       turnAround();
       killPlayer();
    }
    public ball(){
        velocity = 0;        
    }
    public boolean isOnSolidGround() {
        boolean isOnGround = false;
        
        if (getY() > getWorld().getHeight() - 50) isOnGround = true;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / 2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / 2, Platform.class) != null) 
        isOnGround = true;
        return isOnGround;
    }
    public boolean didBumpHead(){
        boolean bumpedHead = false;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / -2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / -2, Platform.class) != null)
        bumpedHead = true;        
        return bumpedHead;        
    }
    public void fall(){
        setLocation(getX(), getY() + velocity);
        if (isOnSolidGround()) {
            velocity = 0;
            
            while (isOnSolidGround()){
                setLocation(getX(), getY() - 1);
        }
        setLocation(getX(),getY() + 1);
        }
        else if (velocity < 0 && didBumpHead()) velocity = 0;
        else velocity += GRAVITY;
    }
    public void rollAround()
    {
        if((animationCounter % 5 == 0)&&(movingLeft == false)&&(animationRoll==true))
        {
            animateRoll();
        }
        if((animationCounter % 5 == 0)&&(movingLeft == true)&&(animationRoll==true))
        {
            animateRollLeft();
        }
    }    
    public void animateRoll()
    {
        if(frame == 1)
        {
            setImage(ball1);
        }
        else if(frame == 2)
        {
            setImage(ball2);
        }
        else if(frame == 3)
        {
            setImage(ball3);
        }
        else if(frame == 4)
        {
            setImage(ball4);
        }
        else if(frame == 5)
        {
            setImage(ball5);
        }
        else if(frame == 6)
        {
            setImage(ball6);
        }
        else if(frame == 7)
        {
            setImage(ball7);
            frame = 1;
            return;
        }
        frame ++;
    }
    public void animateRollLeft()
    {
        if(frame == 1)
        {
            setImage(ballL1);
        }
        else if(frame == 2)
        {
            setImage(ballL2);
        }
        else if(frame == 3)
        {
            setImage(ballL3);
        }
        else if(frame == 4)
        {
            setImage(ballL4);
        }
        else if(frame == 5)
        {
            setImage(ballL5);
        }
        else if(frame == 6)
        {
            setImage(ballL6);
        }
        else if(frame == 7)
        {
            setImage(ballL7);
            frame = 1;
            return;
        }
        frame ++;
    }
    public void turnAround()
    {
        if (isTouching(stopperRight.class))
        {
            speed = -speed;
            movingLeft = true;
        }
        if (isTouching(stopperLeft.class))
        {
            speed = -speed;
            movingLeft = false;
        }
    }
    public void killPlayer()
    {
        Actor touchedBall = getOneIntersectingObject(playerNinja.class);
        if(isTouching(playerNinja.class))
        {
           Greenfoot.playSound("death1.wav");
           MyWorld.stopSoundCnt++;
           getWorld().removeObject(touchedBall);
           
        }
    }
}
