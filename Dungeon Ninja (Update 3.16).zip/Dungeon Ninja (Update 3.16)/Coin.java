
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Coin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Coin extends Actor
{
    private GreenfootImage Coin1 = new GreenfootImage("Coin-1.png");
    private GreenfootImage Coin2 = new GreenfootImage("Coin-2.png");
    private GreenfootImage Coin3 = new GreenfootImage("Coin-3.png");
    private GreenfootImage Coin4 = new GreenfootImage("Coin-4.png");
    private GreenfootImage Coin5 = new GreenfootImage("Coin-5.png");
    private GreenfootImage Coin6 = new GreenfootImage("Coin-6.png");
    
    private int frame = 1;
    private int animationCounter = 0;  
    /**
     * Act - do whatever the Coin wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        animateSpin();
        animationCounter ++;
        
    }    
    public void animateSpin()
    {    
        if(animationCounter % 7 == 0)
        {
                 if(frame == 1)
                {
                    setImage(Coin1);
                }
                else if(frame == 2)
                {
                    setImage(Coin2);
                }
                else if(frame == 3)
                {
                    setImage(Coin3);
                }
                else if(frame == 4)
                {
                    setImage(Coin4);
                }
                else if(frame == 5)
                {
                    setImage(Coin5);
                }
                else if(frame == 6)
                {
                    setImage(Coin6);
                    frame = 1;
                    return;
                }
                frame ++;
        }
    }
}  
