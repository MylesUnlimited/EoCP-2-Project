import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GameOver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOver extends World
{
    public static int worldNumber;
    /**
     * Constructor for objects of class GameOver.
     * 
     */
    public GameOver()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
    }
    public void act()
    {
        showText("Press Enter to Try Again", 390, 350);
        if ((Greenfoot.isKeyDown("ENTER"))&&(worldNumber == 1))
        {
            Greenfoot.setWorld(new MyWorld());
        }
        if ((Greenfoot.isKeyDown("ENTER"))&&(worldNumber == 2))
        {
            Greenfoot.setWorld(new MyWorld_2());
        }
        if ((Greenfoot.isKeyDown("ENTER"))&&(worldNumber == 3))
        {
            Greenfoot.setWorld(new MyWorld_3());
        }
    }

}
