import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    public static int Score = 0;
    GreenfootSound backgroundMusic = new GreenfootSound("Galaxy-Junner2.mp3");
    public static int stopSoundCnt = 0;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    public void act()
    {
        showText("Score: "+Score, 740, 15);
        if (stopSoundCnt == 0)
        {
            backgroundMusic.playLoop();
        }
        if (stopSoundCnt > 0)
        {
            backgroundMusic.stop();
            Greenfoot.setWorld(new GameOver());
        }
        if (stopSoundCnt < 0)
        {
           backgroundMusic.stop();
           Greenfoot.setWorld(new Success());
        }
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        showText("Score: "+Score, 740, 15);
        stopSoundCnt = 0;
        Score = 0;
        playerNinja playerNinja = new playerNinja();
        addObject(playerNinja,672,516);

        //Platforms
        Platform platform = new Platform(60, 60);
        addObject(platform,16,587);
        Platform platform1 = new Platform(60, 60);
        addObject(platform1,76,587);
        Platform platform2 = new Platform(60, 60);
        addObject(platform2,136,587);
        Platform platform3 = new Platform(60, 60);
        addObject(platform3,196,587);
        Platform platform4 = new Platform(60, 60);
        addObject(platform4,256,587);
        Platform platform5 = new Platform(60, 60);
        addObject(platform5,316,587);
        Platform platform6 = new Platform(60, 60);
        addObject(platform6,376,587);
        Platform platform7 = new Platform(60, 60);
        addObject(platform7,436,587);
        Platform platform8 = new Platform(60, 60);
        addObject(platform8,496,587);
        Platform platform9 = new Platform(60, 60);
        addObject(platform9,556,587);
        Platform platform10 = new Platform(60, 60);
        addObject(platform10,616,587);
        Platform platform11 = new Platform(60, 60);
        addObject(platform11,676,587);
        Platform platform12 = new Platform(60, 60);
        addObject(platform12,736,587);
        Platform platform13 = new Platform(60, 60);
        addObject(platform13,796,587);

        Platform platform14 = new Platform(60, 15);
        addObject(platform14,556,467);
        Platform platform15 = new Platform(60, 15);
        addObject(platform15,616,467);
        Platform platform16 = new Platform(60, 15);
        addObject(platform16,676,467);
        Platform platform17 = new Platform(60, 15);
        addObject(platform17,736,467);
        Platform platform18 = new Platform(60, 15);
        addObject(platform18,796,467);

        Platform platform20 = new Platform();
        addObject(platform20,496,467);
        Platform platform21 = new Platform();
        addObject(platform21,436,467);
        Platform platform22 = new Platform();
        addObject(platform22,376,467);
        Platform platform23 = new Platform();
        addObject(platform23,316,467);
        Platform platform24 = new Platform();
        addObject(platform24,256,467);
        Platform platform25 = new Platform();
        addObject(platform25,196,467);

        Platform platform26 = new Platform();
        addObject(platform26,50,370);
        Platform platform27 = new Platform();
        addObject(platform27,150,370);
        Platform platform28 = new Platform();
        addObject(platform28,250,370);
        Platform platform29 = new Platform();
        addObject(platform29,350,370);
        Platform platform30 = new Platform();
        addObject(platform30,450,370);
        Platform platform31 = new Platform();
        addObject(platform31,550,370);

        Platform platform39 = new Platform();
        addObject(platform39,616,273);
        Platform platform40 = new Platform();
        addObject(platform40,556,273);
        Platform platform32 = new Platform();
        addObject(platform32,496,273);
        Platform platform33 = new Platform();
        addObject(platform33,436,273);
        Platform platform34 = new Platform();
        addObject(platform34,376,273);
        Platform platform35 = new Platform();
        addObject(platform35,316,273);
        Platform platform36 = new Platform();
        addObject(platform36,256,273);
        Platform platform37 = new Platform();
        addObject(platform37,196,273);

        Platform platform48 = new Platform();
        addObject(platform48,227,100);
        Platform platform47 = new Platform();
        addObject(platform47,434,129);
        Platform platform49 = new Platform();
        addObject(platform49,44,59);
        platform49.setLocation(48,70);
        Platform platform51 = new Platform();
        addObject(platform51,650,176);

        Coin coin = new Coin();
        addObject(coin,44,518);
        Coin coin2 = new Coin();
        addObject(coin2,222,55);
        Coin coin3 = new Coin();
        addObject(coin3,431,89);
        Coin coin4 = new Coin();
        addObject(coin4,649,138);
        Coin coin5 = new Coin();
        addObject(coin5,356,517);
        Coin coin6 = new Coin();
        addObject(coin6,289,422);
        Coin coin7 = new Coin();
        addObject(coin7,452,427);
        Coin coin8 = new Coin();
        addObject(coin8,590,426);
        Coin coin9 = new Coin();
        addObject(coin9,730,425);
        Coin coin10 = new Coin();
        addObject(coin10,452,329);
        Coin coin11 = new Coin();
        addObject(coin11,276,321);
        Coin coin12 = new Coin();
        addObject(coin12,112,325);
        Coin coin13 = new Coin();
        addObject(coin13,276,230);
        Coin coin14 = new Coin();
        addObject(coin14,478,223);
        
        BinaryPrompt B1 = new BinaryPrompt();
        addObject(B1,44,30);

        spikes spikes2 = new spikes();
        addObject(spikes2,173,260);
        spikes spikes3 = new spikes();
        addObject(spikes3,372,260);
        spikes spikes4 = new spikes();
        addObject(spikes4,784,454);
        spikes spikes5 = new spikes();
        addObject(spikes5,5,550);

        Platform platform45 = new Platform();
        addObject(platform45,710,370);

        platform39.setLocation(306,273);
        spikes spikes7 = new spikes();
        addObject(spikes7,732,356);
        spikes spikes6 = new spikes();
        addObject(spikes6,12,356);
    }
}
