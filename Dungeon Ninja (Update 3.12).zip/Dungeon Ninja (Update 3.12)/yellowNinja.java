import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class yellowNinja here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class yellowNinja extends Actor
{   
    private GreenfootImage walk1 = new GreenfootImage("yellowStandingR1.png");
    private GreenfootImage walk2 = new GreenfootImage("yellowStandingR2.png");
    private GreenfootImage walk3 = new GreenfootImage("yellowStandingR3.png");
    private GreenfootImage walk4 = new GreenfootImage("yellowStandingR4.png");
    private GreenfootImage walkL1 = new GreenfootImage("yellowStandingL1.png");
    private GreenfootImage walkL2 = new GreenfootImage("yellowStandingL2.png");
    private GreenfootImage walkL3 = new GreenfootImage("yellowStandingL3.png");
    private GreenfootImage walkL4 = new GreenfootImage("yellowStandingL4.png");
    private GreenfootImage standing = new GreenfootImage("yellowStanding.png");
    
    private int frame = 1;
    private int animationCounter = 0;
    private final int GRAVITY = 1;
    private int velocity;
    public yellowNinja(){
        velocity = 0;
        
    }
    /**
     * Act - do whatever the playerNinja wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        fall();
        if (Greenfoot.isKeyDown("up") && isOnSolidGround()) jump();
        animateIdle();
        moveAround();// Add your action code here.
        animationCounter ++;
    }
    public void moveAround()
    {
        if(Greenfoot.isKeyDown("right"))
        {
            setLocation(getX() + 3, getY());
            if(animationCounter % 10 == 0)
            {
                animateRight();
            }
        }
        if(Greenfoot.isKeyDown("left"))
        {
            setLocation(getX() - 3, getY());
            if(animationCounter % 10 == 0)
            {
                animateLeft();
            }
        } 
    }
    public void animateIdle()
    {
        if (((Greenfoot.isKeyDown("left"))== false) && ((Greenfoot.isKeyDown("right"))== false))
        {
            setImage(standing);
        }
    }
    public void animateRight()
    {
        if(frame == 1)
        {
            setImage(walk1);
        }
        else if(frame == 2)
        {
            setImage(walk2);
        }
        else if(frame == 3)
        {
            setImage(walk3);
        }
        else if(frame == 4)
        {
            setImage(walk4);
            frame = 1;
            return;
        }
        frame ++;
    }
    public void animateLeft()
    {
        if(frame == 1)
        {
            setImage(walkL1);
        }
        else if(frame == 2)
        {
            setImage(walkL2);
        }
        else if(frame == 3)
        {
            setImage(walkL3);
        }
        else if(frame == 4)
        {
            setImage(walkL4);
            frame = 1;
            return;
        }
        frame ++;
    }
    public void fall(){
        setLocation(getX(), getY() + velocity);
        if (isOnSolidGround()) {
            velocity = 0;
            
            while (isOnSolidGround()){
                setLocation(getX(), getY() - 1);
        }
        setLocation(getX(),getY() + 1);
    }
        else if (velocity < 0 && didBumpHead()) velocity = 0;
        else velocity += GRAVITY;
    }
    public  void jump() {
        velocity = -17;
    }
    public boolean isOnSolidGround() {
        boolean isOnGround = false;
        
        if (getY() > getWorld().getHeight() - 50) isOnGround = true;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / 2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / 2, Platform.class) != null) 
        isOnGround = true;
        
        return isOnGround;
    }
    public boolean didBumpHead(){
        boolean bumpedHead = false;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / -2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / -2, Platform.class) != null)
        bumpedHead = true;
        
        return bumpedHead;
        
    }
}    

