import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class launcherLeft here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class launcherLeft extends Actor
{   
    int counter = 0;
    public static int timer = 0;
    /**
     * Act - do whatever the launcher wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(timer % 500 == 0)
        {
            shootBullet();
            counter++;
        }
    }
    public void shootBullet()
    {
            bulletLeft counter = new bulletLeft();
            getWorld().addObject(counter,getX()-13, getY()-6);
    }
}
