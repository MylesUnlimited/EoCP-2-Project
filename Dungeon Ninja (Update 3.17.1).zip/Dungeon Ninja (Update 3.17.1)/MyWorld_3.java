import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld_3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld_3 extends World
{
    public static int ballTimer = 0;
    /**
     * Constructor for objects of class MyWorld_3.
     * 
     */
    public MyWorld_3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(830, 600, 1);
        prepare();
        
    }
    public void act()
    {
        showText("Score: "+MyWorld.Score, 740, 15);
        if ((ballTimer == 500)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 500)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
        if ((ballTimer == 1000)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 1000)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
        if ((ballTimer == 1500)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 1500)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
        if ((ballTimer == 2000)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 2000)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
        if ((ballTimer == 2500)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 2500)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
        if ((ballTimer == 3000)&&(ball.movingLeft==true))
        {
            ball.speed = ball.speed-3;
        }
        if ((ballTimer == 3000)&&(ball.movingLeft==false))
        {
            ball.speed = ball.speed+3;
        }
          if (ballTimer == 3500)
        {
            ball.speed = 0;
            ball.animationRoll = false;
        }
        if (ballTimer == 3600)
        {
            Greenfoot.setWorld(new Success());
        }
        ballTimer++;
    }       
    
    private void prepare()
    {
        ball.animationRoll=true;
        GameOver.worldNumber = 3;
        showText("Score: "+MyWorld.Score, 740, 15);
        ballTimer = 0;
        ball.speed = -3;

        //Platforms
        Platform platform = new Platform(60, 60);
        addObject(platform,16,587);
        Platform platform1 = new Platform(60, 60);
        addObject(platform1,76,587);
        Platform platform2 = new Platform(60, 60);
        addObject(platform2,136,587);
        Platform platform3 = new Platform(60, 60);
        addObject(platform3,196,587);
        Platform platform4 = new Platform(60, 60);
        addObject(platform4,256,587);
        Platform platform5 = new Platform(60, 60);
        addObject(platform5,316,587);
        Platform platform6 = new Platform(60, 60);
        addObject(platform6,376,587);
        Platform platform7 = new Platform(60, 60);
        addObject(platform7,436,587);
        Platform platform8 = new Platform(60, 60);
        addObject(platform8,496,587);
        Platform platform9 = new Platform(60, 60);
        addObject(platform9,556,587);
        Platform platform10 = new Platform(60, 60);
        addObject(platform10,616,587);
        Platform platform11 = new Platform(60, 60);
        addObject(platform11,676,587);
        Platform platform12 = new Platform(60, 60);
        addObject(platform12,736,587);
        Platform platform13 = new Platform(60, 60);
        addObject(platform13,796,587);
        Platform platform14 = new Platform(60, 60);
        addObject(platform14,856,587);

        ball ball = new ball();
        addObject(ball,693,524);
        playerNinja playerNinja = new playerNinja();
        addObject(playerNinja,92,532);

        stopperLeft stopperLeft = new stopperLeft();
        addObject(stopperLeft,0,544);
        stopperRight stopperRight = new stopperRight();
        addObject(stopperRight,830,537);

        Coin coin = new Coin();
        addObject(coin,797,480);
        Coin coin2 = new Coin();
        addObject(coin2,705,480);
        Coin coin3 = new Coin();
        addObject(coin3,614,480);
        Coin coin4 = new Coin();
        addObject(coin4,511,480);
        Coin coin5 = new Coin();
        addObject(coin5,413,480);
        Coin coin6 = new Coin();
        addObject(coin6,325,480);
        Coin coin7 = new Coin();
        addObject(coin7,241,480);
        Coin coin8 = new Coin();
        addObject(coin8,170,480);
        Coin coin9 = new Coin();
        addObject(coin9,98,480);
        Coin coin10 = new Coin();
        addObject(coin10,24,480);

        Coin coin11 = new Coin();
        addObject(coin11,64,419);
        Coin coin12 = new Coin();
        addObject(coin12,140,419);
        Coin coin13 = new Coin();
        addObject(coin13,211,419);
        Coin coin14 = new Coin();
        addObject(coin14,281,419);
        Coin coin15 = new Coin();
        addObject(coin15,368,419);
        Coin coin16 = new Coin();
        addObject(coin16,458,419);
        Coin coin17 = new Coin();
        addObject(coin17,560,419);
        Coin coin18 = new Coin();
        addObject(coin18,662,419);
        Coin coin19 = new Coin();
        addObject(coin19,754,419);
    }
}
