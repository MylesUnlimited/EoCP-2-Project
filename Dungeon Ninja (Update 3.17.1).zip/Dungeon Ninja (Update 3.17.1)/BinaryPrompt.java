import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.*;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class BinaryPrompt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class BinaryPrompt extends Actor
{   
    private GreenfootImage doorOpen = new GreenfootImage("Door Open.png");
    private GreenfootImage doorClose = new GreenfootImage("Door Close.png");
    //public static String b = "";
    public static Random rand = new Random();
    public static int num = rand.nextInt(100);
    public static String x = "0";
    /**
     * Act - do whatever the BinaryPrompt wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(isTouching(playerNinja.class))
        {
            setImage(doorOpen);
        }else{
            setImage(doorClose);
        }
        CallPrompt();
    }
    public void CallPrompt()
    {   
        Actor touchedBinaryPrompt = getOneIntersectingObject(playerNinja.class);
        if(isTouching(playerNinja.class))
        {
               Scanner scnr = new Scanner(System.in);
               
               //Random rand = new Random();

               //int num = rand.nextInt(100);

               

               //String sin = JOptionPane.showInputDialog("The binary form of "+num+" is:");
    
               JFrame f;

               if (x.equals(MyWorld.Binary)){
                   f=new JFrame();  
                   //JOptionPane.showMessageDialog(f,"You are Correct!"); 
                   WinPlayer();
                }
               else if (!x.equals(MyWorld.Binary)){
                    f=new JFrame();
                    //JOptionPane.showMessageDialog(f,"You are Wrong!");
                    killPlayer();
                }        
        }
    }
    public void WinPlayer()
    {
        Actor touchedSpikes = getOneIntersectingObject(playerNinja.class);
        if(isTouching(playerNinja.class))
        {
           MyWorld.stopSoundCnt--;
           getWorld().removeObject(touchedSpikes);
           
        }
    }
    public void killPlayer()
    {
        Actor touchedSpikes = getOneIntersectingObject(playerNinja.class);
        if(isTouching(playerNinja.class))
        {
           Greenfoot.playSound("death1.wav");
           MyWorld.stopSoundCnt++;
           getWorld().removeObject(touchedSpikes);
           
        }
    }
}
