import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class mover here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class mover extends Actor
{   
    public static boolean moverTouch;
    public mover() {
        this(60, 15);
    }
    public mover(int width, int height) {
        GreenfootImage image= getImage();
        image.scale(width, height);
        setImage(image);
    }
    /**
     * Act - do whatever the mover wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(moverTouch == true)
        {
            setLocation(getX()+1, getY());
        }
        if(moverTouch == false)
        {
            setLocation(getX()-1, getY());
        } 
    }    
}
