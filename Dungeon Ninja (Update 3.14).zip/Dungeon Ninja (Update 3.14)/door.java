import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class door extends Actor
{   
    private GreenfootImage doorOpen = new GreenfootImage("Door Open.png");
    private GreenfootImage doorClose = new GreenfootImage("Door Close.png");
    /**
     * Act - do whatever the door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(isTouching(playerNinja.class))
        {
            setImage(doorOpen);
        }else{
            setImage(doorClose);
        }
    }    
}
