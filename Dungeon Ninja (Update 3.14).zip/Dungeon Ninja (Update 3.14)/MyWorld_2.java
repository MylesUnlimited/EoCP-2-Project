import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld_3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld_2 extends World
{
    GreenfootSound backgroundMusic = new GreenfootSound("Galaxy-Junner2.mp3");   
    /**
     * Constructor for objects of class MyWorld_3.
     * 
     */
    public MyWorld_2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(830, 600, 1); 
        prepare();
    }    
    public void act()
    {
        showText("Score: "+MyWorld.Score, 740, 15);
        if (MyWorld.stopSoundCnt == 0)
        {
            backgroundMusic.playLoop();
        }
        if (MyWorld.stopSoundCnt > 0)
        {
            backgroundMusic.stop();
            Greenfoot.setWorld(new GameOver());
        }
        if (MyWorld.stopSoundCnt < 0)
        {
           backgroundMusic.stop();
           Greenfoot.setWorld(new Success());
        }
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        GameOver.worldNumber = 2;
        showText("Score: "+MyWorld.Score, 740, 15);
        MyWorld.stopSoundCnt = 0;
        BinaryPrompt binaryPrompt = new BinaryPrompt();
        addObject(binaryPrompt,35,55);

        launcher launcher = new launcher();
        addObject(launcher,27,525);
        launcher launcher2 = new launcher();
        addObject(launcher2,28,396);
        launcherLeft launcherLeft = new launcherLeft();
        addObject(launcherLeft,452,235);

        launcher.timer = 0;
        playerNinja.isOnMover = false;

        //Platforms
        Platform platform = new Platform(60, 60);
        addObject(platform,10,568);
        Platform platform1 = new Platform(60, 60);
        addObject(platform1,120,568);
        Platform platform2 = new Platform(60, 60);
        addObject(platform2,180,568);
        Platform platform3 = new Platform(60, 60);
        addObject(platform3,240,568);
        Platform platform4 = new Platform(60, 60);
        addObject(platform4,300,568);
        Platform platform5 = new Platform(60, 60);
        addObject(platform5,360,568);
        Platform platform7 = new Platform(60, 60);
        addObject(platform7,420,568);
        Platform platform8 = new Platform(60, 60);
        addObject(platform8,480,568);
        Platform platform9 = new Platform(60, 60);
        addObject(platform9,70,568);

        spikes spikes = new spikes();
        addObject(spikes,539,580);
        spikes spikes1 = new spikes();
        addObject(spikes1,594,580);
        spikes spikes2 = new spikes();
        addObject(spikes2,650,580);
        spikes spikes3 = new spikes();
        addObject(spikes3,705,580);
        spikes spikes4 = new spikes();
        addObject(spikes4,760,580);
        spikes spikes5 = new spikes();
        addObject(spikes5,815,580);

        Platform platform10 = new Platform();
        addObject(platform10,525,593);
        Platform platform11 = new Platform();
        addObject(platform11,580,593);
        Platform platform12 = new Platform();
        addObject(platform12,635,593);
        Platform platform13 = new Platform();
        addObject(platform13,690,593);
        Platform platform14 = new Platform();
        addObject(platform14,745,593);
        Platform platform15 = new Platform();
        addObject(platform15,800,593);

        Platform platform16 = new Platform();
        addObject(platform16,599,504);
        Platform platform17 = new Platform();
        addObject(platform17,730,450);
        Platform platform18 = new Platform();
        addObject(platform18,560,416);
        Platform platform19 = new Platform();
        addObject(platform19,505,416);
        Platform platform20 = new Platform();
        addObject(platform20,450,416);
        Platform platform21 = new Platform();
        addObject(platform21,395,416);
        Platform platform22 = new Platform();
        addObject(platform22,340,416);
        Platform platform23 = new Platform();
        addObject(platform23,285,416);
        Platform platform24 = new Platform();
        addObject(platform24,230,416);
        Platform platform25 = new Platform();
        addObject(platform25,175,416);
        Platform platform26 = new Platform();
        addObject(platform26,120,416);
        Platform platform27 = new Platform();
        addObject(platform27,65,416);
        Platform platform28 = new Platform();
        addObject(platform28,10,416);

        Platform platform30 = new Platform();
        addObject(platform30,60,320);

        Platform platform31 = new Platform();
        addObject(platform31,220,254);
        Platform platform32 = new Platform();
        addObject(platform32,275,254);
        Platform platform33 = new Platform();
        addObject(platform33,330,254);
        Platform platform34 = new Platform();
        addObject(platform34,385,254);
        Platform platform35 = new Platform();
        addObject(platform35,440,254);

        Platform platform37 = new Platform();
        addObject(platform37,720,192);

        Platform platform38 = new Platform();
        addObject(platform38,615,93);
        Platform platform39 = new Platform();
        addObject(platform39,560,93);
        Platform platform40 = new Platform();
        addObject(platform40,505,93);
        Platform platform41 = new Platform();
        addObject(platform41,450,93);
        Platform platform42 = new Platform();
        addObject(platform42,395,93);
        Platform platform43 = new Platform();
        addObject(platform43,340,93);
        Platform platform44 = new Platform();
        addObject(platform44,285,93);
        Platform platform45 = new Platform();
        addObject(platform45,230,93);
        Platform platform46 = new Platform();
        addObject(platform46,175,93);
        Platform platform47 = new Platform();
        addObject(platform47,120,93);
        Platform platform48 = new Platform();
        addObject(platform48,65,93);
        Platform platform49 = new Platform();
        addObject(platform49,10,93);

        mover mover = new mover();
        addObject(mover,457,192);

        stopperLeft stopperLeft = new stopperLeft();
        addObject(stopperLeft,402,192);
        stopperRight stopperRight = new stopperRight();
        addObject(stopperRight,686,192);

        playerNinja playerNinja = new playerNinja();
        addObject(playerNinja,272,509);
        Coin coin = new Coin();
        addObject(coin,594,479);
        Coin coin2 = new Coin();
        addObject(coin2,728,418);
        Coin coin3 = new Coin();
        addObject(coin3,77,520);
        Coin coin4 = new Coin();
        addObject(coin4,457,519);
        Coin coin5 = new Coin();
        addObject(coin5,512,384);
        Coin coin6 = new Coin();
        addObject(coin6,339,386);
        Coin coin7 = new Coin();
        addObject(coin7,73,388);
        Coin coin8 = new Coin();
        addObject(coin8,204,389);
        Coin coin9 = new Coin();
        addObject(coin9,31,289);
        Coin coin10 = new Coin();
        addObject(coin10,88,287);
        Coin coin11 = new Coin();
        addObject(coin11,196,225);
        Coin coin12 = new Coin();
        addObject(coin12,282,223);
        Coin coin13 = new Coin();
        addObject(coin13,414,227);
        coin12.setLocation(316,225);
        Coin coin14 = new Coin();
        addObject(coin14,556,156);
        Coin coin15 = new Coin();
        addObject(coin15,712,162);
        Coin coin16 = new Coin();
        addObject(coin16,495,64);
        Coin coin17 = new Coin();
        addObject(coin17,312,65);
        Coin coin18 = new Coin();
        addObject(coin18,132,64);
    }
}
