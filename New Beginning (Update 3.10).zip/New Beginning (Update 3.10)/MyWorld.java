import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        jumper jumper = new jumper();
        addObject(jumper,341,141);

        ninja5 ninja5 = new ninja5();
        addObject(ninja5,40,100);

        playerNinja playerNinja = new playerNinja();
        addObject(playerNinja,597,181);
        
        //Platforms
        Platform platform = new Platform(60, 60);
        addObject(platform,16,587);
        Platform platform1 = new Platform(60, 60);
        addObject(platform1,76,587);
        Platform platform2 = new Platform(60, 60);
        addObject(platform2,136,587);
        Platform platform3 = new Platform(60, 60);
        addObject(platform3,196,587);
        Platform platform4 = new Platform(60, 60);
        addObject(platform4,256,587);
        Platform platform5 = new Platform(60, 60);
        addObject(platform5,316,587);
        Platform platform6 = new Platform(60, 60);
        addObject(platform6,376,587);
        Platform platform7 = new Platform(60, 60);
        addObject(platform7,436,587);
        Platform platform8 = new Platform(60, 60);
        addObject(platform8,496,587);
        Platform platform9 = new Platform(60, 60);
        addObject(platform9,556,587);
        Platform platform10 = new Platform(60, 60);
        addObject(platform10,616,587);
        Platform platform11 = new Platform(60, 60);
        addObject(platform11,676,587);
        Platform platform12 = new Platform(60, 60);
        addObject(platform12,736,587);
        Platform platform13 = new Platform(60, 60);
        addObject(platform13,796,587);
        
        Platform platform14 = new Platform(60, 45);
        addObject(platform14,556,467);
        Platform platform15 = new Platform(60, 45);
        addObject(platform15,616,467);
        Platform platform16 = new Platform(60, 45);
        addObject(platform16,676,467);
        Platform platform17 = new Platform(60, 45);
        addObject(platform17,736,467);
        Platform platform18 = new Platform(60, 45);
        addObject(platform18,796,467);


    }
}
