import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        character character = new character();
        addObject(character,102,202);
        jumper jumper = new jumper();
        addObject(jumper,341,141);
        Platform platform = new Platform(5000, 110);
        addObject(platform, 100,550);
        ninja5 ninja5 = new ninja5();
        addObject(ninja5,40,100);
        building building = new building(100,100);

        playerNinja playerNinja = new playerNinja();
        addObject(playerNinja,597,181);
        character.setLocation(104,196);
        removeObject(character);
    }
}
