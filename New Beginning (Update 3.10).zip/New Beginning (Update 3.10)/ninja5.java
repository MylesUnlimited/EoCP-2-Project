import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ninja5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ninja5 extends Actor
{
    private final int GRAVITY = 1;
    private int velocity;
    public ninja5(){
        velocity = 0;
        
    }
    public void act() 
    {
        fall();
        if (Greenfoot.isKeyDown("V") && isOnSolidGround()) jump();
        move();
    }   
    public void fall(){
        setLocation(getX(), getY() + velocity);
        if (isOnSolidGround()) {
            velocity = 0;
            
            while (isOnSolidGround()){
                setLocation(getX(), getY() - 1);
        }
        setLocation(getX(),getY() + 1);
    }
        else if (velocity < 0 && didBumpHead()) velocity = 0;
        else velocity += GRAVITY;
    }
    public  void jump() {
        velocity = -20;
    }
    public boolean isOnSolidGround() {
        boolean isOnGround = false;
        
        if (getY() > getWorld().getHeight() - 50) isOnGround = true;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / 2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / 2, Platform.class) != null) 
        isOnGround = true;
        
        return isOnGround;
    }
    public boolean didBumpHead(){
        boolean bumpedHead = false;
        
        int imageWidth = getImage().getWidth();
        int imageHeight = getImage().getHeight();
        if (getOneObjectAtOffset(imageWidth / -2, imageHeight / -2, Platform.class)!= null || 
        getOneObjectAtOffset(imageWidth / 2, imageHeight / -2, Platform.class) != null)
        bumpedHead = true;
        
        return bumpedHead;
        
    }
    /**
     * Act - do whatever the ninja5 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
       
    public void move() {
        int y = getY();
        int x = getX();
        if(Greenfoot.isKeyDown("I"))y--;
        if(Greenfoot.isKeyDown("K"))y++;
        if(Greenfoot.isKeyDown("J"))x--;
        if(Greenfoot.isKeyDown("L"))x++;
        setLocation(x, y);
    }
}
